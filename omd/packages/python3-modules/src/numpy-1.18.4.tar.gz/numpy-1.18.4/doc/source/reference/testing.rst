.. _testing-guidelines:

Testing Guidelines
==================

.. include:: ../../TESTS.rst.txt
   :start-line: 6
