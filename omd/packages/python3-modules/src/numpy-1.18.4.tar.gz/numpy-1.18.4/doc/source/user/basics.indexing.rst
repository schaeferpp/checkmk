.. _basics.indexing:

********
Indexing
********

.. seealso::

   :ref:`Indexing <arrays.indexing>`

   :ref:`Indexing routines <routines.indexing>`

.. automodule:: numpy.doc.indexing
