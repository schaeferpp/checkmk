extending_distributions.pyx
---------------------------

.. literalinclude:: ../../../../../../numpy/random/_examples/cython/extending_distributions.pyx
    :language: cython
